<template>
  <div class="features_items">
    <!--RetailSale_items-->
    {{ title }}
  </div>
  <!--RetailSale_items-->
</template>

<script>
// import RetailSale from "./RetailSale";
export default {
  name: `RetailSale`,
  data() {
    return {
      title: "Retail Sale",
    };
  },
  components: {
    // HeaderTop,
  },
};
</script>
